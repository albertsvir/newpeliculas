const express = require('express');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const router = express.Router();

const SECRET = 'tu_clave_secreta';

function verifyUser(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  const decoded = jwt.verify(token, SECRET);
  if (decoded.role !== 'user') return res.status(403).json({ error: 'Solo usuarios' });
  req.user = decoded;
  next();
}

router.post('/:movieId', verifyUser, async (req, res) => {
  await User.findByIdAndUpdate(req.user.id, { $addToSet: { listaPeliculas: req.params.movieId } });
  res.json({ message: 'Película agregada' });
});

router.delete('/:movieId', verifyUser, async (req, res) => {
  await User.findByIdAndUpdate(req.user.id, { $pull: { listaPeliculas: req.params.movieId } });
  res.json({ message: 'Película eliminada' });
});

router.get('/list', verifyUser, async (req, res) => {
  const user = await User.findById(req.user.id).populate('listaPeliculas');
  res.json(user.listaPeliculas);
});

module.exports = router;