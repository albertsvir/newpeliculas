const express = require('express');
const Movie = require('../models/Movie');
const jwt = require('jsonwebtoken');
const router = express.Router();

const SECRET = 'tu_clave_secreta';

function verifyAdmin(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  const decoded = jwt.verify(token, SECRET);
  if (decoded.role !== 'admin') return res.status(403).json({ error: 'No autorizado' });
  req.user = decoded;
  next();
}

router.get('/', async (req, res) => {
  const movies = await Movie.find();
  res.json(movies);
});

router.post('/', verifyAdmin, async (req, res) => {
  const movie = await Movie.create(req.body);
  res.status(201).json(movie);
});

router.put('/:id', verifyAdmin, async (req, res) => {
  const updated = await Movie.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

router.delete('/:id', verifyAdmin, async (req, res) => {
  await Movie.findByIdAndDelete(req.params.id);
  res.json({ message: 'Película eliminada' });
});

module.exports = router;
